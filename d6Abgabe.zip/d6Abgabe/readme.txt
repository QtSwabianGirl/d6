In WeeklyBuild1, WeeklyBuild2 und WeeklyBuild3 ist die Anwendung auf dem Stand der 1., 2. und 3. Woche zu finden.
In Endabgabe ist die fertige Anwendung zu finden.